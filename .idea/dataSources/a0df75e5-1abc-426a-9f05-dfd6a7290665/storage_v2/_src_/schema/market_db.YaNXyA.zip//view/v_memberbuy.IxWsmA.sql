create definer = root@localhost view v_memberbuy as
select `b`.`mem_id`                       AS `mem_id`,
       `m`.`mem_name`                     AS `mem_name`,
       `b`.`prod_name`                    AS `prod_name`,
       `m`.`addr`                         AS `addr`,
       concat(`m`.`phone1`, `m`.`phone2`) AS `연락처`
from (`market_db`.`buy` `b` join `market_db`.`member` `m` on (`b`.`mem_id` = `m`.`mem_id`));

