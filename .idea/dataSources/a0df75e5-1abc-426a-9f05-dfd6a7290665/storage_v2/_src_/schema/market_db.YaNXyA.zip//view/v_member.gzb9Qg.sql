create definer = root@localhost view v_member as
select `market_db`.`member`.`mem_id`   AS `mem_id`,
       `market_db`.`member`.`mem_name` AS `mem_name`,
       `market_db`.`member`.`addr`     AS `addr`
from `market_db`.`member`;

-- comment on column v_member.mem_id not supported: 회원 아이디(PK)

