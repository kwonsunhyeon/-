create definer = root@localhost view v_height167 as
select `market_db`.`member`.`mem_id`     AS `mem_id`,
       `market_db`.`member`.`mem_name`   AS `mem_name`,
       `market_db`.`member`.`mem_number` AS `mem_number`,
       `market_db`.`member`.`addr`       AS `addr`,
       `market_db`.`member`.`phone1`     AS `phone1`,
       `market_db`.`member`.`phone2`     AS `phone2`,
       `market_db`.`member`.`height`     AS `height`,
       `market_db`.`member`.`debut_date` AS `debut_date`,
       `market_db`.`member`.`email`      AS `email`
from `market_db`.`member`
where `market_db`.`member`.`height` >= 167;

-- comment on column v_height167.mem_id not supported: 회원 아이디(PK)

-- comment on column v_height167.mem_number not supported: 회원번호 32767까지

-- comment on column v_height167.height not supported: 부호없는 정수 최대값 127

